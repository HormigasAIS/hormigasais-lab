#!/bin/bash
echo 'Strings lite'