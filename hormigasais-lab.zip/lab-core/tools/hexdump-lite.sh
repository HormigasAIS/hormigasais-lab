#!/bin/bash
echo 'Hexdump lite'