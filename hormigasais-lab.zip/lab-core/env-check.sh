#!/bin/bash
echo 'Checking environment...'