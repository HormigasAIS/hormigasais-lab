#!/bin/bash
echo 'Start HormigasAIS Lab'